**************
I/O with Numpy
**************

.. toctree::
   :maxdepth: 2

   basics.io.genfromtxt
