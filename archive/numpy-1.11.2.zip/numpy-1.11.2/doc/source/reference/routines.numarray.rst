**********************
Numarray compatibility
**********************

The numarray module was removed in Numpy 1.9.
